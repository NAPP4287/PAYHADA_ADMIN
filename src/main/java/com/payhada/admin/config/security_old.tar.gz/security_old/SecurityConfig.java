 package com.payhada.admin.config.security_old;

 import org.apache.logging.log4j.core.config.Order;
 import org.springframework.beans.factory.annotation.Value;
 import org.springframework.context.annotation.Bean;
 import org.springframework.context.annotation.Configuration;
 import org.springframework.security.authentication.AuthenticationManager;
 import org.springframework.security.config.BeanIds;
 import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
 import org.springframework.security.config.annotation.web.builders.HttpSecurity;
 import org.springframework.security.config.annotation.web.builders.WebSecurity;
 import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
 import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
 import org.springframework.security.web.authentication.AuthenticationFailureHandler;
 import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
 import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

 @Configuration
 @EnableWebSecurity
 @Order(3)
 public class SecurityConfig extends WebSecurityConfigurerAdapter  {
     private UserAuthenticationProvider authenticationProvider;
     private AuthenticationFailureHandler failureHandler;
     private AuthenticationSuccessHandler successHandler;

     public SecurityConfig(UserAuthenticationProvider authenticationProvider,
                           AuthenticationFailureHandler failureHandler, AuthenticationSuccessHandler successHandler) {
         this.authenticationProvider = authenticationProvider;
         this.failureHandler = failureHandler;
         this.successHandler = successHandler;
     }

     protected void configure(AuthenticationManagerBuilder auth) throws Exception {
         auth.authenticationProvider(authenticationProvider);   // 로그인 정보를 확인하고, 권한을 확인 => 인증 토근 발행
     }

     @Value("${spring.profiles.active}")
     private String serverMode;

     @Override
     public void configure(WebSecurity web) throws Exception
     {
         web.ignoring()
                 .antMatchers("/static/**")
                 .antMatchers("/login", "/")
                 .antMatchers("/api/v2/login/**");
     }

     @Override
     protected void configure(HttpSecurity http) throws Exception {
         http.csrf().disable();
         http.exceptionHandling().accessDeniedPage("/login/denied");
         http.authorizeRequests().antMatchers("/api/v2/login").permitAll();
         http.formLogin().disable();

         http.addFilterAt(getAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);

//         http.csrf().disable().authorizeRequests()
//                 .antMatchers("/config/**").hasAnyRole("A", "D", "M", "MAS")
//                 .anyRequest().authenticated()
//                 .and().addFilterBefore(customUsernamePasswordAuthenticationFilter(), CustomUsernamePasswordAuthenticationFilter.class);
////         http.csrf().ignoringAntMatchers("/**");
//         http.formLogin()
//                 .loginPage("/login")
//                 .usernameParameter("id")
//                 .passwordParameter("pwd")
//                 .loginProcessingUrl("/api/v2/login")
//                 // .successHandler(successHandler)
//                 // .failureHandler(failureHandler)
//                 // .defaultSuccessUrl("/main")
//                 // .failureUrl("/login")
//                 .permitAll();
//         http.logout()
//                 .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
//                 .logoutSuccessUrl("/login")
//                 .invalidateHttpSession(true);
//         http.exceptionHandling()
//                 .accessDeniedPage("/login/denied");

//		if(active.equals("test") || active.equals("prod")) {
//			http.requiresChannel().antMatchers("/login").requiresSecure();
//		}
     }

     protected CustomUsernamePasswordAuthenticationFilter getAuthenticationFilter() {
         CustomUsernamePasswordAuthenticationFilter authFilter = new CustomUsernamePasswordAuthenticationFilter();
         try {
             authFilter.setFilterProcessesUrl("/api/v2/login");
             authFilter.setAuthenticationManager(this.authenticationManagerBean());
             authFilter.setUsernameParameter("id");
             authFilter.setPasswordParameter("pwd");
             authFilter.setAuthenticationSuccessHandler(successHandler);
             authFilter.setAuthenticationFailureHandler(failureHandler);
         } catch (Exception e) {
             e.printStackTrace();
         }
         return authFilter;
     }

     // // 로그인 성공 처리를 위한 Handler
     // @Bean
     // public AuthenticationSuccessHandler successHandler() {
     // 	// log.info("[ BEAN ] : AuthenticationSuccessHandler");
     // 	// loginIdname, defaultUrl
     // 	return new CustomAuthenticationSuccessHandler("username", "/loginSuccess");
     // }

     // // 실패 처리를 위한 Handler
     // @Bean
     // public AuthenticationFailureHandler failureHandler() {
     // //  log.info("[ BEAN ] : failureHandler");
     // 	return new CustomAuthenticationFailureHandler("username", "password" , "loginRedirectUrl" , "exceptionMsgName" , "/login". "dsf");
     // }

     @Bean(name = BeanIds.AUTHENTICATION_MANAGER)
     @Override
     public AuthenticationManager authenticationManagerBean() throws Exception {
         // TODO Auto-generated method stub
         return super.authenticationManagerBean();
     }

     @Bean
     public CustomUsernamePasswordAuthenticationFilter customUsernamePasswordAuthenticationFilter() throws Exception {
         CustomUsernamePasswordAuthenticationFilter customUsernamePasswordAuthenticationFilter = new CustomUsernamePasswordAuthenticationFilter();
         customUsernamePasswordAuthenticationFilter.setAuthenticationManager(authenticationManagerBean());
         return customUsernamePasswordAuthenticationFilter;
     }

 }
