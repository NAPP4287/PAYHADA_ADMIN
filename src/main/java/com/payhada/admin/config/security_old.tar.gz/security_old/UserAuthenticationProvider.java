package com.payhada.admin.config.security_old;

import com.payhada.admin.common.util.SHAEncryption;
import com.payhada.admin.config.security_old.otp.OtpAuth;
import com.payhada.admin.model.MemberDTO;
import com.payhada.admin.service.user.MemberService;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
@RequiredArgsConstructor
public class UserAuthenticationProvider implements AuthenticationProvider {
    private final Logger log = LoggerFactory.getLogger(getClass());

    MemberService memberService;
    AuthenticationUtil authUtil;
    OtpAuth otpAuth;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        System.out.println("authentication:" + new JSONObject(authentication.getDetails()));

         AuthenticationDetails detail = ((AuthenticationDetails) authentication.getDetails());
         Map<String, String> map = new HashMap();
         map.put("id", detail.getId());
         map.put("pwd", detail.getPwd());
         map.put("code", detail.getCode());
        System.out.println("map ::" + map);
        String id = ((AuthenticationDetails) authentication.getDetails()).getId();
        String pwd = ((AuthenticationDetails) authentication.getDetails()).getPwd();

        System.out.println("id ::" +id);
        System.out.println("pwd ::" +pwd);
        String code = null; // ((AuthenticationDetails) authentication.getDetails()).getCode();
        String memberNo = null; // ((AuthenticationDetails) authentication.getDetails()).getMemberNo();

        // String id = authentication.getName();
        // String pwd = (String) authentication.getCredentials();
        // String code = "";
        // String memberNo = "";

        MemberDTO userDto = new MemberDTO();
        MemberDTO memberDto = new MemberDTO();
        ArrayList<SimpleGrantedAuthority> authorities = new ArrayList<>();



        if("".equals(code) || code == null ){

            //otp 코드가 없을시 로그인 체크 로직
            // 1. id 존재 체크
            int id_chk = memberService.getMemberId(id);
            if(id_chk == 0) {
                log.info("[ {} ]는 존재하지 않는 ID입니다.", id);
                throw new UsernameNotFoundException("존재하지 않는 ID 입니다.");
            }

            String encPw =  SHAEncryption.encrypt512(pwd);

            //로그인용
            MemberDTO loginDto = new MemberDTO();
            loginDto.setId(id);
            loginDto.setPwd(encPw);
            // 2. 아이디 + 비밀번호로 로그인 체크 (비밀번호 횟수 카운트, 비활성화 여부 확인)
            userDto = memberService.getMemberWithId(loginDto);

            //     2-2. 비활성화 null 일때
            //     3-2. 로그인 실패
            //          1. 실패 카운트 ++ 세션에 에러메세지 저장
            //             1-1. 카운트가 6이면 잠김 lock time : 현재시간, 활성화 -> 비활성화
            //             1-2. 카운트가 5이하면 카운트만 업데이트
            if (userDto == null) {
                log.info("비밀번호가 일치하지 않습니다."); // 아이디는 있는데 비밀번호가 틀렸을 때

//                failCnt(id); // TODO 수정 필요 (2022.12.22 주석처리함)
                throw new BadCredentialsException("비밀번호가 일치하지 않습니다.");
            } else if(userDto.getLock_time() != null){
                //     2-1. 비활성화 Y (10분제한인지 확인) login_lock_time -> 10분이 지났으면 -> N , 카운트 null TODO 수정 필요(2022.12.22 주석처리함)
//                boolean lock = unlockTimeExpired(userDto, "login");
//                if(lock == false) {
//                    log.info("비활성화 된 계정, 10분 후 로그인 재시도 필요");
//                    throw new DisabledException("비활성화 된 계정, 10분 후 로그인 재시도 필요");
//                }
            }
            userDto.setPwd(null);
            // 3. 로그인 성공 / 실패
            //     3-1. 로그인 성공
            //          1. RESET 비밆번호 카운트 null + lock time null
            userDto.setLock_time(null);
            userDto.setPwd_fail_cnt(0);
            memberService.updateFailAttempts(userDto);


            //          2. 난수생성 otp_code/ otp_dt 업데이트
            userDto.setOtp_code(randOTPCode());
            memberService.updateOtp(userDto);

            userDto = memberService.getMemberWithId(loginDto);

            Map<String, Object> sendResult = new HashMap<>();
            // sendResult = memberService.getMembeSendEmail(userDto);


            throw new InsufficientAuthenticationException("OTP");
        }else{
            //otp 코드가 있을시 otp 검증 후 로그인 처리
            //로그인용

            userDto = memberService.getMemberOtpDetail(memberNo);

//            boolean lock = unlockTimeExpired(userDto, "otp");
//            if(lock == true) {
//                log.info("3분이 지남. 로그인 재시도 필요");
//                throw new InternalAuthenticationServiceException("OTP TIME FAIL");
//            }else{
//                log.info("3분전 otp 인증코드 가능");
                if(code.equals(userDto.getOtp_code())){
                    // otp 코드가 같으면, 로그인 성공
                    authorities.add(new SimpleGrantedAuthority("ROLE_"+userDto.getUser_role()));
                }else{
                    // 다르면 otp 재입력

                    throw new InsufficientAuthenticationException("OTP NUMBER FAIL");
                }
//            }
            log.info("AUTH CHECK : "+authorities.toString());
            log.info("AUTH CHECK : "+userDto);


        }


//        String code = details.get("code");
//
//        if (!otpAuth.verifyCode(code)) {
//            log.info("code error");
//            throw new BadCredentialsException("Login Error !!");
//        }

        return new UsernamePasswordAuthenticationToken(userDto, null, authorities);
    }


    @Override
    public boolean supports(Class authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }

    // 로그인 실패 카운트 TODO 수정 필요 (2022.12.22 주석처리함)
//    private MemberDTO failCnt(String id) {
//        MemberDTO dto = memberService.getFailAttempts(id);
//        dto.setId(id);
//
//        if(dto.getPwd_fail_cnt() == 5){
//            dto.setIs_enabled("Y");
////            dto.setLock_time(new Date());
//
//            memberService.updateFailAttempts(dto);
//        } else if (dto.getPwd_fail_cnt() > 5) {
//            boolean expired = unlockTimeExpired(dto, "login");
//
//            if(expired == false) {
//                log.info("비활성화 된 계정, 10분 후 로그인 재시도 필요");
//                throw new DisabledException("비활성화 된 계정, 10분 후 로그인 재시도 필요");
//            }
//        }
//        memberService.updateFailCount(id); // 카운트 증가
//
//        return dto;
//    }

    // 난수 생성
    private String randOTPCode() {
        Random random = new Random(System.currentTimeMillis());

        int range = (int)Math.pow(10, 6);
        int trim = (int)Math.pow(10, 6-1);
        int result = random.nextInt(range) + trim;

        if(result > range){
            result = result - trim;
        }

        return String.valueOf(result);
    }

    // 계정 비활성화 시간 10분 확인하고 업데이트 TODO 수정 필요 (2022.12.22 주석처리함)
//    public boolean unlockTimeExpired(MemberDTO dto, String type) {
//        long startLockTime ;
//        if(type.equals("login")){
//            startLockTime =  dto.getLock_time().getTime() + (600 * 1000);
//        }else{
//            startLockTime =  dto.getOtp_dt().getTime() + (180 * 1000);
//        }
//        long endLockTime = System.currentTimeMillis();
//
//        if(startLockTime < endLockTime) {
//            if(type.equals("login")){
//                dto.setPwd_fail_cnt(0);
//                dto.setIs_enabled("N");
//                dto.setLock_time(null);
//
//                memberService.updateFailAttempts(dto);
//            }else{
//
//            }
//
//            return true;
//        }
//        return false;
//    }

}