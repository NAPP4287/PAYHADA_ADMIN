package com.payhada.admin.service;

public interface KeyService {

	public int setDbKey(String dbKey);

}

