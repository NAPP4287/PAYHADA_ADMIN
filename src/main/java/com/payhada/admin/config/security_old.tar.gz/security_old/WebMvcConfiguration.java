package com.payhada.admin.config.security_old;

//@Configuration
//@EnableWebMvc
//public class WebMvcConfiguration {

/*    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters)
    {
    	converters.add(new StringHttpMessageConverter());
    	converters.add(new ByteArrayHttpMessageConverter());
    } */

//    @Override
//    public void addResourceHandlers(ResourceHandlerRegistry registry) {
//            registry.addResourceHandler("/**")
////                    .addResourceLocations("/public", "classpath:/templates/")
//                    .addResourceLocations("/", "classpath:/static/")
//                    .setCachePeriod(31556926);
//    }
//}