package com.payhada.admin.config.security_old.otp;


import com.google.zxing.WriterException;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class OtpAuth {

    public void createOtp() throws IOException, WriterException {
        OtpUtil otpUtil = new OtpUtil();
        String code =  otpUtil.getTOTPCode(OtpConfig.secretKey);
        String barCodeUrl =  otpUtil.getGoogleAuthenticatorBarCode(OtpConfig.secretKey, OtpConfig.account, "payhada");
        otpUtil.createQRCode(barCodeUrl, OtpConfig.path, 300, 300);
    }

    public Boolean verifyCode(String code) {
        OtpUtil otpUtil = new OtpUtil();
        String _code = otpUtil.getTOTPCode(OtpConfig.secretKey);
        return code.equals(_code);
    }

    //    @Bean
    public OtpAuth getOtpAuth() throws IOException, WriterException {
        OtpAuth otpAuth = new OtpAuth();
        otpAuth.createOtp();
        return otpAuth;
    }

}
