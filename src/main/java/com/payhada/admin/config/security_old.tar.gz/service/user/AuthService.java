package com.payhada.admin.service.user;

import com.payhada.admin.common.util.SHAEncryption;
import com.payhada.admin.dao.AuthDAO;
import com.payhada.admin.model.MemberDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.security.auth.login.AccountNotFoundException;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {
    private final AuthDAO authDAO;

    public MemberDTO loginWithLoginIdAndPwd(MemberDTO memberDTO) throws Exception {
        memberDTO.setPwd(SHAEncryption.encrypt512(memberDTO.getPwd()));
        MemberDTO account = authDAO.selectMemberWithLoginId(memberDTO);
        if(account==null) {
            throw new AccountNotFoundException(String.format("로그인 실패 ID :[%s]", memberDTO.getId()));
        }
        return account;
    }
}
