package com.payhada.admin.config.security_old;

import javax.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payhada.admin.model.LoginDTO;
import lombok.Getter;
import org.springframework.security.web.authentication.WebAuthenticationDetails;

import java.io.IOException;
import java.util.stream.Collectors;

public class AuthenticationDetails extends WebAuthenticationDetails {

    @Getter
    private String id;

    @Getter
    private String pwd;

    @Getter
    private String code;

    @Getter
    private String memberNo;

    public AuthenticationDetails(HttpServletRequest request) {
        super(request);
        try {
            /** 인증 방식 : (로그인 폼 X) JSON format API */
            ObjectMapper objectMapper = new ObjectMapper();
            System.out.println(request.getReader());
            LoginDTO loginDTO = objectMapper.readValue(request.getReader().lines().collect(Collectors.joining()), LoginDTO.class);
            System.out.println("loginDTO :::"  + loginDTO);

            id = loginDTO.getId();
            pwd = loginDTO.getPwd();
            code = loginDTO.getCode();
            memberNo = loginDTO.getMemberNo();
        } catch(IOException e) {
            e.printStackTrace();
        }

//        id = request.getParameter("id");
//        pwd = request.getParameter("pwd");
//        code = request.getParameter("code");
//        memberNo = request.getParameter("memberNo");
    }

}
