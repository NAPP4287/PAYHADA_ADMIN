package com.payhada.admin.config.security_old.otp;

public class OtpConfig {

    public static String secretKey = "OBQXS2DBMRQTAOJSHA======";// ""payhada0928";
    public static String account = "payhada@payhada.com";
    //    public static String path = "./src/main/resources/static/images/qr.png";
    public static String path = "/qr.png";

}
