package com.payhada.admin.config.security_old;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

@Component
public class AuthenticationUtil {

    public String getPram(HttpServletRequest req, String name) {
        return req.getParameter(name);
    }

    public Map<String, String> getDetails(Authentication authentication) {
        AuthenticationDetails detail = ((AuthenticationDetails)
                authentication.getDetails());
        Map<String, String> map = new HashMap();
        map.put("id", detail.getId());
        map.put("pwd", detail.getPwd());
        map.put("code", detail.getCode());

        return map;
    }

}
